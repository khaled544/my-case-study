package com.InventoryManagement.service;

import com.InventoryManagement.beans.InsertingWareHouseDetailsBean;
import com.InventoryManagement.dao.InsertingWareHouseDetailsDaoImplementation;

public class InsertingWareHouseDetailsServiceImplementation implements InsertingWareHouseDetailsService{
	private InsertingWareHouseDetailsDaoImplementation wareHouseDao;


	@Override
	public void insertWareHouseDetails(InsertingWareHouseDetailsBean wareHouseBean) {
		System.out.println("in Inserting WareHouse Details Service");
		
		
		
		
		wareHouseDao.insertWareHouseDetails(wareHouseBean);
	}
	
	public void setWareHouseDao(InsertingWareHouseDetailsDaoImplementation wareHouseDao){
		this.wareHouseDao=wareHouseDao;
	}
	
}

	
	