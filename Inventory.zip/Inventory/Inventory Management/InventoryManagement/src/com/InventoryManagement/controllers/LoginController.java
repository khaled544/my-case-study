package com.InventoryManagement.controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.InventoryManagement.beans.LoginBean;
import com.InventoryManagement.service.LoginService;
@Controller
public class LoginController {
	@Autowired
	private LoginService loginService;
	@RequestMapping(value="/validating.html",method=RequestMethod.POST)
	public ModelAndView validating(@ModelAttribute("cmdlog")LoginBean lb,HttpServletRequest request){
		
		
		String s=loginService.validating(lb);
		if(s.equalsIgnoreCase("INVALID")){
		return new ModelAndView("HomePage");
		}
		else if(s.equalsIgnoreCase("USER")){
			return new ModelAndView("UserSuccess");
			}
		else
		{
			return new ModelAndView("success");
		}
	}	
	public void setLoginService(LoginService loginService)
	{
		this.loginService=loginService;
	}
}
