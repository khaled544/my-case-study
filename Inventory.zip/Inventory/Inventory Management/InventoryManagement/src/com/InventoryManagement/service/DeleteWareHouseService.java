package com.InventoryManagement.service;

import com.InventoryManagement.beans.InsertingWareHouseDetailsBean;

public interface DeleteWareHouseService {
	void deleteWareHouse(InsertingWareHouseDetailsBean wareHouse);
}
