package com.InventoryManagement.service;

import com.InventoryManagement.beans.InsertingItemDetailsBean;

public interface InsertingItemDetailsService {
	void insertItemDetails(InsertingItemDetailsBean itemBean);

}
