package com.InventoryManagement.beans;

import java.io.Serializable;

public class InsertingVendorDetailsBean implements Serializable {
	
	private String vendorId;
	private String vendorName;
	private String phoneNumber;
	private String address;
	private String itemsDistributing;
	
	public InsertingVendorDetailsBean() {
		super();
	}
	public InsertingVendorDetailsBean(String vendorId, String vendorName,
			String phoneNumber, String address, String itemsDistributing) {
		super();
		this.vendorId = vendorId;
		this.vendorName = vendorName;
		this.phoneNumber = phoneNumber;
		this.address = address;
		this.itemsDistributing = itemsDistributing;
	}
	public String getVendorId() {
		return vendorId;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getItemsDistributing() {
		return itemsDistributing;
	}
	public void setItemsDistributing(String itemsDistributing) {
		this.itemsDistributing = itemsDistributing;
	}
	
	
	
	
	
	

}
