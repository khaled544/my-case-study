package com.InventoryManagement.dao;

import com.InventoryManagement.beans.InsertingItemDetailsBean;

public interface DeleteItemDao {
	void deleteItem(InsertingItemDetailsBean item);
}
