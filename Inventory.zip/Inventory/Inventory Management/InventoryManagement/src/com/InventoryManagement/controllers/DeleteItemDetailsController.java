package com.InventoryManagement.controllers;


	import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.InventoryManagement.beans.InsertingItemDetailsBean;
import com.InventoryManagement.service.DeleteItemService;



		@Controller
		public class DeleteItemDetailsController {

			@Autowired
		    private DeleteItemService deleteItemService;
			

		    public void setItemService(DeleteItemService deleteItemService) {
				this.deleteItemService = deleteItemService;
			}

			@RequestMapping(value="/delete.html", method = RequestMethod.POST)
		    public ModelAndView insert(@ModelAttribute("cmdItems") InsertingItemDetailsBean item) 
		    {
		    	System.out.println("In Controller.....Before");
		    	
		    	deleteItemService.deleteItem(item);
		        
		        System.out.println("In Controller.....After");
		        
		        return new ModelAndView("DeletingItems");
		    }



}
