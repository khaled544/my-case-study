package com.InventoryManagement.service;

import java.util.List;

import com.InventoryManagement.beans.RetreivingVendorDetailsBean;
import com.InventoryManagement.dao.RetreiveVendorDetailsDaoImplementation;

public class RetreivingVendorDetailsServiceImplementation implements RetreivingVendorDetailsService{

	private RetreiveVendorDetailsDaoImplementation dao;
	
	public List validate(RetreivingVendorDetailsBean rb)
	{
		return dao.validate(rb);
		
	}
	
	public void setDao(RetreiveVendorDetailsDaoImplementation dao){
		this.dao=dao;
	}
	public RetreiveVendorDetailsDaoImplementation getDao(){
		return dao;
	}
	

}
