package com.InventoryManagement.dao;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.InventoryManagement.beans.InsertingItemDetailsBean;
import com.InventoryManagement.beans.InsertingWareHouseDetailsBean;

public class DeleteWareHouseDaoImplementation implements DeleteWareHouseDao{
private HibernateTemplate ht;
	
@Override
public void deleteWareHouse(InsertingWareHouseDetailsBean wareHouse) {
	
		
		
		System.out.println("deleteWareHouse of WareHouseDAOImpl class.....");
		
      ht.delete(wareHouse);
        
	}
	
	public void setHt(HibernateTemplate ht) {
        this.ht = ht;
    }

}
