package com.InventoryManagement.dao;

import com.InventoryManagement.beans.InsertingVendorDetailsBean;

public interface DeleteVendorsDao {
	void deleteVendor(InsertingVendorDetailsBean vendor);
}
