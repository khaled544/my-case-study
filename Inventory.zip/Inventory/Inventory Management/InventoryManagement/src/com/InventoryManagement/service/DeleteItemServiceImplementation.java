package com.InventoryManagement.service;


	import com.InventoryManagement.beans.InsertingItemDetailsBean;
import com.InventoryManagement.dao.DeleteItemDaoImplementation;

	public class DeleteItemServiceImplementation  implements DeleteItemService {

		private DeleteItemDaoImplementation deleteDao;

		@Override
		public void deleteItem(InsertingItemDetailsBean item) {
			
			System.out.println("deleteItem method of ItemServiceImpl method!!!");
			deleteDao.deleteItem(item);
		}
		
		public void setDeleteDao(DeleteItemDaoImplementation deleteDao) {
	        this.deleteDao = deleteDao;
	    }

}
