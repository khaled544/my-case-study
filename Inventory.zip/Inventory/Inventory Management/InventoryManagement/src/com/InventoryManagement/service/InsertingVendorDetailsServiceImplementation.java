package com.InventoryManagement.service;

import com.InventoryManagement.beans.InsertingVendorDetailsBean;
import com.InventoryManagement.dao.InsertingVendorDetailsDaoImplementation;

public class InsertingVendorDetailsServiceImplementation implements InsertingVendorDetailsService{
	private InsertingVendorDetailsDaoImplementation vendorDao;


	@Override
	public void insertVendorDetails(InsertingVendorDetailsBean vendorBean) {
		System.out.println("in Inserting Vendor Details Service");
		
		
		
		
		vendorDao.insertVendorDetails(vendorBean);
	}
	
	public void setVendorDao(InsertingVendorDetailsDaoImplementation vendorDao){
		this.vendorDao=vendorDao;
	}
	
}

	
	