package com.InventoryManagement.dao;

import java.util.List;

import com.InventoryManagement.beans.RetreivingVendorDetailsBean;

public interface RetreiveVendorDetailsDao {

	public List validate(RetreivingVendorDetailsBean rb);
}
