package com.InventoryManagement.service;

import com.InventoryManagement.beans.LoginBean;
import com.InventoryManagement.dao.LoginDao;

public class LoginService {
      private LoginDao loginDao;

	public String validating(LoginBean lb)
	{
		return loginDao.validating(lb);
	}
	
	public void setLoginDao(LoginDao loginDao)
	{
		this.loginDao=loginDao;
	}
}
