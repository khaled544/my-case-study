package com.InventoryManagement.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.InventoryManagement.beans.InsertingItemDetailsBean;
import com.InventoryManagement.beans.InsertingWareHouseDetailsBean;
import com.InventoryManagement.service.InsertingItemDetailsService;
import com.InventoryManagement.service.InsertingItemDetailsServiceImplementation;
import com.InventoryManagement.service.InsertingWareHouseDetailsService;
import com.InventoryManagement.service.InsertingWareHouseDetailsServiceImplementation;

@Controller
public class InsertingWareHouseDetailsController {
	
	@Autowired
	private InsertingWareHouseDetailsService wareHouseService;
	
	public void setWareHouseDetailsService(InsertingWareHouseDetailsService wareHouseService){
		
		this.wareHouseService = wareHouseService;
	}
	
	@RequestMapping(value="/wareHouseDetails.html",method=RequestMethod.POST)
	
	public ModelAndView insert(@ModelAttribute("cmdWareHouse") InsertingWareHouseDetailsBean wareHouseBean){
		System.out.println("in Controller Before.........");
		
		wareHouseService.insertWareHouseDetails(wareHouseBean);
		
		System.out.println("in Controller After.........");
		return new ModelAndView("WareHouseDetails");
	}
	

	//if you want to print any Collection use this annotation
    @ModelAttribute("myList")
    private List getItems() {
        List l = new ArrayList();
     //   l.add("abc");
       // l.add("xyz");
        return l;
    }

	
	public void setWareHouseDetails(InsertingWareHouseDetailsServiceImplementation wareHouseService){
		System.out.println("in Controller At Service Overriding Class.........");
		this.wareHouseService = wareHouseService;
	}
	
	
	
}



