package com.InventoryManagement.dao;

import com.InventoryManagement.beans.InsertingVendorDetailsBean;

public interface InsertingVendorDetailsDao {
	void insertVendorDetails(InsertingVendorDetailsBean vendorBean);
}
