package com.InventoryManagement.dao;

import java.util.List;

import com.InventoryManagement.beans.RetreivingWareHouseDetailsBean;

public interface RetreiveWareHouseDetailsDao {

	public List validate(RetreivingWareHouseDetailsBean wrb);
}
