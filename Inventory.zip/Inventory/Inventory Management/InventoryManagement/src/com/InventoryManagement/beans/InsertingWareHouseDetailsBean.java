package com.InventoryManagement.beans;

import java.io.Serializable;

public class InsertingWareHouseDetailsBean implements Serializable{
	
	private String wareHouseId;
	private String wareHouseName;
	private String wareHouseAddress;
	private String wareHouseCapacity;
	
	public InsertingWareHouseDetailsBean() {
		super();
	}
	public InsertingWareHouseDetailsBean(String wareHouseId,
			String wareHouseName, String wareHouseAddress,
			String wareHouseCapacity) {
		super();
		this.wareHouseId = wareHouseId;
		this.wareHouseName = wareHouseName;
		this.wareHouseAddress = wareHouseAddress;
		this.wareHouseCapacity = wareHouseCapacity;
	}
	public String getWareHouseId() {
		return wareHouseId;
	}
	public void setWareHouseId(String wareHouseId) {
		this.wareHouseId = wareHouseId;
	}
	public String getWareHouseName() {
		return wareHouseName;
	}
	public void setWareHouseName(String wareHouseName) {
		this.wareHouseName = wareHouseName;
	}
	public String getWareHouseAddress() {
		return wareHouseAddress;
	}
	public void setWareHouseAddress(String wareHouseAddress) {
		this.wareHouseAddress = wareHouseAddress;
	}
	public String getWareHouseCapacity() {
		return wareHouseCapacity;
	}
	public void setWareHouseCapacity(String wareHouseCapacity) {
		this.wareHouseCapacity = wareHouseCapacity;
	}
}
	