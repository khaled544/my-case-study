package com.InventoryManagement.dao;

import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.InventoryManagement.beans.RetreivingWareHouseDetailsBean;

public class RetreiveWareHouseDetailsDaoImplementation implements RetreiveWareHouseDetailsDao{
	private HibernateTemplate ht;
	public List validate(RetreivingWareHouseDetailsBean wrb)
	{
		
		List l;
		l=ht.find("from RetreivingWareHouseDetailsBean where wareHouseId='"+wrb.getWareHouseId()+"'");
		System.out.println("In Dao Implementation");
		return l;
	}
	public void setHt(HibernateTemplate ht)
	{
		this.ht=ht;
	}
	public HibernateTemplate getHt()
	{
		return ht;
	}

}

