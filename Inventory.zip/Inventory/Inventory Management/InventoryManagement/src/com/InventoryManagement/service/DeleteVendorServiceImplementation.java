package com.InventoryManagement.service;


import com.InventoryManagement.beans.InsertingVendorDetailsBean;
import com.InventoryManagement.dao.DeleteVendorDaoImplementation;

	public class DeleteVendorServiceImplementation  implements DeleteVendorService {

		private DeleteVendorDaoImplementation deleteVDao;

		@Override
		public void deleteVendor(InsertingVendorDetailsBean vendor) {
			
			System.out.println("deleteVendor method of VendorServiceImpl method!!!");
			deleteVDao.deleteVendor(vendor);
		}
		
		public void setDeleteVDao(DeleteVendorDaoImplementation deleteVDao) {
	        this.deleteVDao = deleteVDao;
	    }

}
