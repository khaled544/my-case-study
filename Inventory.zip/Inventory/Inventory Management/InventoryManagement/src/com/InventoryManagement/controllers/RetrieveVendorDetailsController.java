package com.InventoryManagement.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.InventoryManagement.beans.RetreivingVendorDetailsBean;
import com.InventoryManagement.service.RetreivingVendorDetailsServiceImplementation;

@Controller
public class RetrieveVendorDetailsController {

	@Autowired
	private RetreivingVendorDetailsServiceImplementation service;
	
	@RequestMapping(value="/validate.html",method=RequestMethod.POST)
	public ModelAndView validate(@ModelAttribute("cmdVendor")RetreivingVendorDetailsBean rb,HttpServletRequest request){
		List l=service.validate(rb);
		System.out.println(service.validate(rb));
		HttpSession session=request.getSession();
		session.setAttribute("details", l);
		return new ModelAndView("RetreiveVendor","List",l);
	}
	
	
	public  void setService(RetreivingVendorDetailsServiceImplementation service){
		this.service=service;
	}
	public  RetreivingVendorDetailsServiceImplementation getService(){
		return service;
	}

}
