package com.InventoryManagement.dao;

import com.InventoryManagement.beans.InsertingWareHouseDetailsBean;

public interface DeleteWareHouseDao {
	void deleteWareHouse(InsertingWareHouseDetailsBean wareHouse);
}
