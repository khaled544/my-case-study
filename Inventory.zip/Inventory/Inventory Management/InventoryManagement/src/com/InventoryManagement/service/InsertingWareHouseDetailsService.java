package com.InventoryManagement.service;

import com.InventoryManagement.beans.InsertingWareHouseDetailsBean;

public interface InsertingWareHouseDetailsService {
	void insertWareHouseDetails(InsertingWareHouseDetailsBean wareHouseBean);

}
