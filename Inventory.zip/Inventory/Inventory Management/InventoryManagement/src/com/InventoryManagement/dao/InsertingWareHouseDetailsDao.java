package com.InventoryManagement.dao;

import com.InventoryManagement.beans.InsertingWareHouseDetailsBean;

public interface InsertingWareHouseDetailsDao {
	void insertWareHouseDetails(InsertingWareHouseDetailsBean wareHouseBean);
}
