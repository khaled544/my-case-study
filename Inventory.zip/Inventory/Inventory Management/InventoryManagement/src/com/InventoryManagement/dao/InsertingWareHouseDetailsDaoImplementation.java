package com.InventoryManagement.dao;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.InventoryManagement.beans.InsertingItemDetailsBean;
import com.InventoryManagement.beans.InsertingWareHouseDetailsBean;

public class InsertingWareHouseDetailsDaoImplementation implements InsertingWareHouseDetailsDao{

	
private HibernateTemplate ht;
	
	
	
	@Override
	public void insertWareHouseDetails(InsertingWareHouseDetailsBean wareHouseBean) {
		System.out.println("in Inserting WareHouse Details Dao Implementation");
		ht.save(wareHouseBean);
		System.out.println("in Inserting WareHouse Details Dao Implementation WareHouse bean saved");
	}

	public void setHt(HibernateTemplate ht) {
		this.ht = ht;
		
	}

	
}

