package com.InventoryManagement.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.InventoryManagement.beans.InsertingItemDetailsBean;
import com.InventoryManagement.service.InsertingItemDetailsService;
import com.InventoryManagement.service.InsertingItemDetailsServiceImplementation;

@Controller
public class InsertingItemDetailsController {
	
	@Autowired
	private InsertingItemDetailsService itemService;
	
	public void setItemDetailsService(InsertingItemDetailsService itemService){
		
		this.itemService = itemService;
	}
	
	@RequestMapping(value="/insertDetails.html",method=RequestMethod.POST)
	
	public ModelAndView insert(@ModelAttribute("cmdItem") InsertingItemDetailsBean itemBean){
		System.out.println("in Controller Before.........");
		
		itemService.insertItemDetails(itemBean);
		
		System.out.println("in Controller After.........");
		return new ModelAndView("ItemDetails");
	}
	

	//if you want to print any Collection use this annotation
    @ModelAttribute("myList")
    private List getItems() {
        List l = new ArrayList();
     //   l.add("abc");
       // l.add("xyz");
        return l;
    }

	
	public void setItemsDetails(InsertingItemDetailsServiceImplementation itemService){
		System.out.println("in Controller At Service Overriding Class.........");
		this.itemService = itemService;
	}
	
	
	
}



