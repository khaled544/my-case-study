package com.InventoryManagement.controllers;


	import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.InventoryManagement.beans.InsertingItemDetailsBean;
import com.InventoryManagement.beans.InsertingWareHouseDetailsBean;
import com.InventoryManagement.service.DeleteItemService;
import com.InventoryManagement.service.DeleteWareHouseService;



		@Controller
		public class DeleteWareHouseDetailsController {

			@Autowired
		    private DeleteWareHouseService deleteWareHouseService;
			

		    public void setWareHouseService(DeleteWareHouseService deleteWareHouseService) {
				this.deleteWareHouseService = deleteWareHouseService;
			}

			@RequestMapping(value="/deletees.html", method = RequestMethod.POST)
		    public ModelAndView insert(@ModelAttribute("cmdWareHouses") InsertingWareHouseDetailsBean wareHouse) 
		    {
		    	System.out.println("In Controller.....Before");
		    	
		    	deleteWareHouseService.deleteWareHouse(wareHouse);
		        
		        System.out.println("In Controller.....After");
		        
		        return new ModelAndView("DeletingWareHouse");
		    }



}
