package com.InventoryManagement.dao;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.InventoryManagement.beans.InsertingItemDetailsBean;
import com.InventoryManagement.beans.InsertingVendorDetailsBean;

public class DeleteVendorDaoImplementation implements DeleteVendorsDao{
private HibernateTemplate ht;
	
@Override
public void deleteVendor(InsertingVendorDetailsBean vendor) {
	
		
		
		System.out.println("deleteVendor of VendorDAOImpl class.....");
      ht.delete(vendor);
        
	}
	
	public void setHt(HibernateTemplate ht) {
        this.ht = ht;
    }

}
