package com.InventoryManagement.service;

import com.InventoryManagement.beans.InsertingItemDetailsBean;

public interface DeleteItemService {
	void deleteItem(InsertingItemDetailsBean item);
}
