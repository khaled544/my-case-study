package com.InventoryManagement.service;

import com.InventoryManagement.beans.InsertingItemDetailsBean;
import com.InventoryManagement.dao.InsertingItemDetailsDaoImplementation;

public class InsertingItemDetailsServiceImplementation implements InsertingItemDetailsService{
	private InsertingItemDetailsDaoImplementation itemDao;


	@Override
	public void insertItemDetails(InsertingItemDetailsBean itemBean) {
		System.out.println("in Inserting Item Details Service");
		
		
		
		
		itemDao.insertItemDetails(itemBean);
	}
	
	public void setItemDao(InsertingItemDetailsDaoImplementation itemDao){
		this.itemDao=itemDao;
	}
	
}

	
	