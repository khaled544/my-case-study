package com.InventoryManagement.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.InventoryManagement.beans.InsertingVendorDetailsBean;
import com.InventoryManagement.service.InsertingVendorDetailsService;
import com.InventoryManagement.service.InsertingVendorDetailsServiceImplementation;

@Controller
public class InsertingVendorDetailsController {

	@Autowired
	private InsertingVendorDetailsService vendorService;
	
public void setVendorDetailsService(InsertingVendorDetailsService vendorService){
		
		this.vendorService = vendorService;
	}
@RequestMapping(value="/vendorDetails.html",method=RequestMethod.POST)

public ModelAndView insert(@ModelAttribute("cmdVendor") InsertingVendorDetailsBean vendorBean){
	System.out.println("in Controller Before.........");
	
	vendorService.insertVendorDetails(vendorBean);
	
	System.out.println("in Controller After.........");
	return new ModelAndView("VendorDetails");
}
@ModelAttribute("myList")
private List getItems() {
    List l = new ArrayList();
 //   l.add("abc");
   // l.add("xyz");
    return l;
}


public void setVendorDetails(InsertingVendorDetailsServiceImplementation vendorService){
	System.out.println("in Controller At Service Overriding Class.........");
	this.vendorService = vendorService;
}

}
