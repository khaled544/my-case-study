package com.InventoryManagement.service;

import java.util.List;

import com.InventoryManagement.beans.RetreivingVendorDetailsBean;
import com.InventoryManagement.beans.RetreivingWareHouseDetailsBean;
import com.InventoryManagement.dao.RetreiveVendorDetailsDaoImplementation;
import com.InventoryManagement.dao.RetreiveWareHouseDetailsDaoImplementation;

public class RetreivingWareHouseDetailsServiceImplementation implements RetreivingWareHouseDetailsService{

	private RetreiveWareHouseDetailsDaoImplementation wdao;
	
	public List validate(RetreivingWareHouseDetailsBean wrb)
	{
		return wdao.validate(wrb);
		
	}
	
	public void setWdao(RetreiveWareHouseDetailsDaoImplementation wdao){
		this.wdao=wdao;
	}
	public RetreiveWareHouseDetailsDaoImplementation getWdao(){
		return wdao;
	}
	

}
