package com.InventoryManagement.controllers;


	import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.InventoryManagement.beans.InsertingItemDetailsBean;
import com.InventoryManagement.beans.InsertingVendorDetailsBean;
import com.InventoryManagement.service.DeleteItemService;
import com.InventoryManagement.service.DeleteVendorService;



		@Controller
		public class DeleteVendorDetailsController {

			@Autowired
		    private DeleteVendorService deleteVendorService;
			

		    public void setVendorService(DeleteVendorService deleteVendorService) {
				this.deleteVendorService = deleteVendorService;
			}

			@RequestMapping(value="/deletes.html", method = RequestMethod.POST)
		    public ModelAndView insert(@ModelAttribute("cmdVendors") InsertingVendorDetailsBean vendor) 
		    {
		    	System.out.println("In Controller.....Before");
		    	
		    	deleteVendorService.deleteVendor(vendor);
		        
		        System.out.println("In Controller.....After");
		        
		        return new ModelAndView("DeletingVendors");
		    }



}
