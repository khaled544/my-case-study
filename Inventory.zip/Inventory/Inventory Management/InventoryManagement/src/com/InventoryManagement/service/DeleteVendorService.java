package com.InventoryManagement.service;

import com.InventoryManagement.beans.InsertingVendorDetailsBean;

public interface DeleteVendorService {
	void deleteVendor(InsertingVendorDetailsBean vendor);
}
