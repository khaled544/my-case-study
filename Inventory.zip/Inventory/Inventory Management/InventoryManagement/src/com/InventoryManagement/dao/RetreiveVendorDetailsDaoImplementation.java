package com.InventoryManagement.dao;

import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.InventoryManagement.beans.RetreivingVendorDetailsBean;

public class RetreiveVendorDetailsDaoImplementation implements RetreiveVendorDetailsDao{
	private HibernateTemplate ht;
	public List validate(RetreivingVendorDetailsBean rb)
	{
		
		List l;
		l=ht.find("from RetreivingVendorDetailsBean where vendorId='"+rb.getVendorId()+"' and vendorName='"+rb.getVendorName()+"'");
		System.out.println("In Dao Implementation");
		return l;
	}
	public void setHt(HibernateTemplate ht)
	{
		this.ht=ht;
	}
	public HibernateTemplate getHt()
	{
		return ht;
	}

}

