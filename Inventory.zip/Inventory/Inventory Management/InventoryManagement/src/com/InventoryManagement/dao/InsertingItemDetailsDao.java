package com.InventoryManagement.dao;

import com.InventoryManagement.beans.InsertingItemDetailsBean;

public interface InsertingItemDetailsDao {
	void insertItemDetails(InsertingItemDetailsBean itemBean);
}
