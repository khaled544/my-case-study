 package com.InventoryManagement.service;

import java.util.List;

import com.InventoryManagement.beans.RetreivingVendorDetailsBean;

public interface RetreivingVendorDetailsService {

	public List validate(RetreivingVendorDetailsBean rb);

}
