package com.InventoryManagement.beans;

import java.io.Serializable;

public class InsertingItemDetailsBean implements Serializable{
	
	private String itemName;
	private String itemQuantity;
	private String price;
	private String itemType;
	public InsertingItemDetailsBean() {
		super();
	}
	public InsertingItemDetailsBean(String itemName, String itemQuantity, String price,
			String itemType) {
		super();
		this.itemName = itemName;
		this.itemQuantity = itemQuantity;
		this.price = price;
		this.itemType = itemType;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getItemQuantity() {
		return itemQuantity;
	}
	public void setItemQuantity(String itemQuantity) {
		this.itemQuantity = itemQuantity;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getItemType() {
		return itemType;
	}
	public void setItemType(String itemType) {
		this.itemType = itemType;
	}
	
	
}
