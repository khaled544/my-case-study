 package com.InventoryManagement.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.InventoryManagement.beans.RetreivingWareHouseDetailsBean;
import com.InventoryManagement.service.RetreivingWareHouseDetailsServiceImplementation;

@Controller
public class RetrieveWareHouseDetailsController {

	@Autowired
	private RetreivingWareHouseDetailsServiceImplementation wservice;
	
	@RequestMapping(value="/validates.html",method=RequestMethod.POST)
	public ModelAndView validate(@ModelAttribute("cmdWareHouse")RetreivingWareHouseDetailsBean wrb,HttpServletRequest request){
		List l=wservice.validate(wrb);
		System.out.println(wservice.validate(wrb));
		HttpSession session=request.getSession();
		session.setAttribute("details", l);
		return new ModelAndView("RetreiveWareHouse","List",l);
	}
	
	
	public  void setWservice(RetreivingWareHouseDetailsServiceImplementation wservice){
		this.wservice=wservice;
	}
	public  RetreivingWareHouseDetailsServiceImplementation getWservice(){
		return wservice;
	}

}
