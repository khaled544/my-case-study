package com.InventoryManagement.dao;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.InventoryManagement.beans.InsertingVendorDetailsBean;
public class InsertingVendorDetailsDaoImplementation implements InsertingVendorDetailsDao{
private HibernateTemplate ht;



@Override
public void insertVendorDetails(InsertingVendorDetailsBean vendorBean) {
	System.out.println("in Inserting Item Details Dao Implementation");
	ht.save(vendorBean);
	System.out.println("in Inserting Item Details Dao Implementation Item bean saved");
}

public void setHt(HibernateTemplate ht) {
	this.ht = ht;
	
}


}



