package com.InventoryManagement.dao;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.InventoryManagement.beans.InsertingItemDetailsBean;

public class DeleteItemDaoImplementation implements DeleteItemDao{
private HibernateTemplate ht;
	
@Override
public void deleteItem(InsertingItemDetailsBean item) {
	
		
		
		System.out.println("deleteItem of ItemDAOImpl class.....");
		
      ht.delete(item);
        
	}
	
	public void setHt(HibernateTemplate ht) {
        this.ht = ht;
    }

}
