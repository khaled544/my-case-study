package com.InventoryManagement.service;

import com.InventoryManagement.beans.InsertingVendorDetailsBean;

public interface InsertingVendorDetailsService {
	void insertVendorDetails(InsertingVendorDetailsBean vendorBean);

}
