package com.InventoryManagement.service;


import com.InventoryManagement.beans.InsertingWareHouseDetailsBean;
import com.InventoryManagement.dao.DeleteWareHouseDaoImplementation;

	public class DeleteWareHouseServiceImplementation  implements DeleteWareHouseService {

		private DeleteWareHouseDaoImplementation deleteWDao;

		@Override
		public void deleteWareHouse(InsertingWareHouseDetailsBean wareHouse) {
			
			System.out.println("deleteWareHouse method of WareHouseServiceImpl method!!!");
			deleteWDao.deleteWareHouse(wareHouse);
		}
		
		public void setDeleteWDao(DeleteWareHouseDaoImplementation deleteWDao) {
	        this.deleteWDao = deleteWDao;
	    }

}
