package com.InventoryManagement.service;

import java.util.List;

import com.InventoryManagement.beans.RetreivingWareHouseDetailsBean;

public interface RetreivingWareHouseDetailsService {

	public List validate(RetreivingWareHouseDetailsBean wrb);

}
