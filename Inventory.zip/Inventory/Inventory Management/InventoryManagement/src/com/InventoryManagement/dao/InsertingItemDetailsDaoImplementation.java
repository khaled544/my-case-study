package com.InventoryManagement.dao;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.InventoryManagement.beans.InsertingItemDetailsBean;

public class InsertingItemDetailsDaoImplementation implements InsertingItemDetailsDao{

	
private HibernateTemplate ht;
	
	
	
	@Override
	public void insertItemDetails(InsertingItemDetailsBean itemBean) {
		System.out.println("in Inserting Item Details Dao Implementation");
		ht.save(itemBean);
		System.out.println("in Inserting Item Details Dao Implementation Item bean saved");
	}

	public void setHt(HibernateTemplate ht) {
		this.ht = ht;
		
	}

	
}

